package com.example.starbucks;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class SubActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sub);
        Button dialog = (Button) findViewById(R.id.btn);
        dialog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Dialog();
            }

        });
    }

    public void Dialog(){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("주문 내역");
        builder.setMessage("나이트로 바닐라 크림 " + count + "잔 " + result +"원. 주문하시겠습니까?");
        builder.setPositiveButton("확인",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(getApplicationContext(),"주문이 접수되었습니다.",Toast.LENGTH_LONG).show();
                    }
                });
        builder.setNegativeButton("취소",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(getApplicationContext(),"주문이 취소되었습니다.",Toast.LENGTH_LONG).show();
                    }
                });
        builder.show();
    }


    public void onBack(View view){
        finish();
    }
    int cost = 6300;
    int count = 1;
    int result = cost*count;

    public void costPlus(View view){
        count++;
        result = cost * count;
        display(result);
        displayCount(count);
    }

    public void costMinus(View view){
        count--;
        result = cost * count;
        display(result);
        displayCount(count);
    }

    public  void  display(int result){
        TextView countview = (TextView) findViewById(R.id.costId);
        countview.setText(String.valueOf(result+"원"));
    }

    public void displayCount(int count){
        TextView countview = (TextView) findViewById(R.id.countId);
        countview.setText(String.valueOf(count));
    }

    public void onClick(View view){
        Intent intent = new Intent(this, dialog.class);
        startActivity(intent);
    }
}
